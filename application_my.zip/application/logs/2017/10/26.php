<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2017-10-26 15:20:24 --- CRITICAL: ErrorException [ 1 ]: Method View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file ~ APPPATH\views\v_index.php [ 0 ] in file:line
2017-10-26 15:20:24 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 15:23:08 --- CRITICAL: ErrorException [ 1 ]: Method View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file ~ APPPATH\views\v_index.php [ 0 ] in file:line
2017-10-26 15:23:08 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 15:26:16 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: title ~ APPPATH\views\v_catalog.php [ 1 ] in E:\OpenServer\domains\kohana\application\views\v_catalog.php:1
2017-10-26 15:26:16 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\views\v_catalog.php(1): Kohana_Core::error_handler(8, 'Undefined varia...', 'E:\\OpenServer\\d...', 1, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#2 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 E:\OpenServer\domains\kohana\application\views\v_index.php(3): Kohana_View->__toString()
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#7 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#11 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#13 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#14 {main} in E:\OpenServer\domains\kohana\application\views\v_catalog.php:1
2017-10-26 15:26:31 --- CRITICAL: ErrorException [ 1 ]: Method View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file ~ APPPATH\views\v_index.php [ 0 ] in file:line
2017-10-26 15:26:31 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 15:28:12 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: title ~ APPPATH\views\v_catalog.php [ 1 ] in E:\OpenServer\domains\kohana\application\views\v_catalog.php:1
2017-10-26 15:28:12 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\views\v_catalog.php(1): Kohana_Core::error_handler(8, 'Undefined varia...', 'E:\\OpenServer\\d...', 1, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#2 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 E:\OpenServer\domains\kohana\application\views\v_index.php(3): Kohana_View->__toString()
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#7 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#11 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#13 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#14 {main} in E:\OpenServer\domains\kohana\application\views\v_catalog.php:1
2017-10-26 15:29:21 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: title ~ APPPATH\views\v_catalog.php [ 1 ] in E:\OpenServer\domains\kohana\application\views\v_catalog.php:1
2017-10-26 15:29:21 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\views\v_catalog.php(1): Kohana_Core::error_handler(8, 'Undefined varia...', 'E:\\OpenServer\\d...', 1, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#2 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 E:\OpenServer\domains\kohana\application\views\v_index.php(3): Kohana_View->__toString()
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#7 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#11 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#13 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#14 {main} in E:\OpenServer\domains\kohana\application\views\v_catalog.php:1
2017-10-26 15:29:24 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: title ~ APPPATH\views\v_catalog.php [ 1 ] in E:\OpenServer\domains\kohana\application\views\v_catalog.php:1
2017-10-26 15:29:24 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\views\v_catalog.php(1): Kohana_Core::error_handler(8, 'Undefined varia...', 'E:\\OpenServer\\d...', 1, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#2 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 E:\OpenServer\domains\kohana\application\views\v_index.php(3): Kohana_View->__toString()
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#7 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#11 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#13 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#14 {main} in E:\OpenServer\domains\kohana\application\views\v_catalog.php:1
2017-10-26 15:31:53 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: title ~ APPPATH\views\v_catalog.php [ 1 ] in E:\OpenServer\domains\kohana\application\views\v_catalog.php:1
2017-10-26 15:31:53 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\views\v_catalog.php(1): Kohana_Core::error_handler(8, 'Undefined varia...', 'E:\\OpenServer\\d...', 1, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#2 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 E:\OpenServer\domains\kohana\application\views\v_index.php(3): Kohana_View->__toString()
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#7 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#11 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#13 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#14 {main} in E:\OpenServer\domains\kohana\application\views\v_catalog.php:1
2017-10-26 15:31:55 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: title ~ APPPATH\views\v_catalog.php [ 1 ] in E:\OpenServer\domains\kohana\application\views\v_catalog.php:1
2017-10-26 15:31:55 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\views\v_catalog.php(1): Kohana_Core::error_handler(8, 'Undefined varia...', 'E:\\OpenServer\\d...', 1, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#2 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 E:\OpenServer\domains\kohana\application\views\v_index.php(3): Kohana_View->__toString()
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#7 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#11 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#13 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#14 {main} in E:\OpenServer\domains\kohana\application\views\v_catalog.php:1
2017-10-26 15:32:45 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: title ~ APPPATH\views\v_catalog.php [ 1 ] in E:\OpenServer\domains\kohana\application\views\v_catalog.php:1
2017-10-26 15:32:45 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\views\v_catalog.php(1): Kohana_Core::error_handler(8, 'Undefined varia...', 'E:\\OpenServer\\d...', 1, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#2 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 E:\OpenServer\domains\kohana\application\views\v_index.php(3): Kohana_View->__toString()
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#7 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#11 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#13 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#14 {main} in E:\OpenServer\domains\kohana\application\views\v_catalog.php:1
2017-10-26 15:34:17 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: title ~ APPPATH\views\v_index.php [ 1 ] in E:\OpenServer\domains\kohana\application\views\v_index.php:1
2017-10-26 15:34:17 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\views\v_index.php(1): Kohana_Core::error_handler(8, 'Undefined varia...', 'E:\\OpenServer\\d...', 1, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#2 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#7 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#10 {main} in E:\OpenServer\domains\kohana\application\views\v_index.php:1
2017-10-26 15:34:35 --- CRITICAL: ErrorException [ 1 ]: Method View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '?>' ~ APPPATH\views\v_index.php [ 0 ] in file:line
2017-10-26 15:34:35 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 16:04:07 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: result ~ APPPATH\views\v_index.php [ 4 ] in E:\OpenServer\domains\kohana\application\views\v_index.php:4
2017-10-26 16:04:07 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\views\v_index.php(4): Kohana_Core::error_handler(8, 'Undefined varia...', 'E:\\OpenServer\\d...', 4, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#2 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#7 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#10 {main} in E:\OpenServer\domains\kohana\application\views\v_index.php:4
2017-10-26 16:06:55 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 16:06:55 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 18:27:57 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH\views\v_index.php [ 3 ] in E:\OpenServer\domains\kohana\application\views\v_index.php:3
2017-10-26 18:27:57 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\views\v_index.php(3): Kohana_Core::error_handler(8, 'Undefined varia...', 'E:\\OpenServer\\d...', 3, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(62): include('E:\\OpenServer\\d...')
#2 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('E:\\OpenServer\\d...', Array)
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#7 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#10 {main} in E:\OpenServer\domains\kohana\application\views\v_index.php:3
2017-10-26 18:28:24 --- CRITICAL: View_Exception [ 0 ]: The requested view template could not be found ~ SYSPATH\classes\Kohana\View.php [ 265 ] in E:\OpenServer\domains\kohana\system\classes\Kohana\View.php:145
2017-10-26 18:28:24 --- DEBUG: #0 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(145): Kohana_View->set_filename('template')
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(30): Kohana_View->__construct('template', NULL)
#2 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller\Template.php(33): Kohana_View::factory('template')
#3 E:\OpenServer\domains\kohana\application\classes\Controller\Index.php(8): Kohana_Controller_Template->before()
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(69): Controller_Index->before()
#5 [internal function]: Kohana_Controller->execute()
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#7 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#10 {main} in E:\OpenServer\domains\kohana\system\classes\Kohana\View.php:145
2017-10-26 20:49:03 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: request ~ APPPATH\classes\Controller\Api.php [ 11 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:11
2017-10-26 20:49:03 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(11): Kohana_Core::error_handler(8, 'Undefined varia...', 'E:\\OpenServer\\d...', 11, Array)
#1 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(25): Controller_Api->get_key()
#2 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#7 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#8 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:11
2017-10-26 20:49:19 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: request ~ APPPATH\classes\Controller\Api.php [ 11 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:11
2017-10-26 20:49:19 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(11): Kohana_Core::error_handler(8, 'Undefined varia...', 'E:\\OpenServer\\d...', 11, Array)
#1 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(25): Controller_Api->get_key()
#2 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#7 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#8 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:11
2017-10-26 20:49:39 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: request ~ APPPATH\classes\Controller\Api.php [ 11 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:11
2017-10-26 20:49:39 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(11): Kohana_Core::error_handler(8, 'Undefined varia...', 'E:\\OpenServer\\d...', 11, Array)
#1 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(25): Controller_Api->get_key()
#2 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#7 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#8 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:11
2017-10-26 21:23:09 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of ArgumentCountError given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(ArgumentCountError))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:23:09 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 21:25:09 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of ArgumentCountError given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(ArgumentCountError))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:25:09 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 21:25:11 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of ArgumentCountError given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(ArgumentCountError))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:25:11 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 21:25:14 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of ArgumentCountError given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(ArgumentCountError))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:25:14 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 21:26:33 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:26:33 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 21:41:19 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:41:19 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 21:41:21 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:41:21 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 21:42:20 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:42:20 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 21:42:32 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:42:32 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 21:42:33 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:42:33 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 21:43:16 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:43:16 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 21:43:17 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:43:17 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 21:45:19 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:45:19 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 21:49:42 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:49:42 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 21:56:10 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:56:10 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 21:59:16 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 21:59:16 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:00:14 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:00:14 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:00:16 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:00:16 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:00:32 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:00:32 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:00:34 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:00:34 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:06:29 --- CRITICAL: ErrorException [ 8 ]: Undefined property: Controller_Api::$_tableClasses ~ APPPATH\classes\Controller\Api.php [ 29 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:29
2017-10-26 22:06:29 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(29): Kohana_Core::error_handler(8, 'Undefined prope...', 'E:\\OpenServer\\d...', 29, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:29
2017-10-26 22:17:36 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:17:36 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:19:12 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:19:12 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:19:15 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:19:15 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:20:31 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:20:31 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:20:49 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:20:49 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:26:16 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:26:16 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:26:18 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:26:18 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:28:49 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:28:49 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:28:50 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:28:50 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:29:02 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:29:02 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:29:03 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:29:03 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:29:09 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:29:09 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:29:10 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:29:10 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:30:57 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:30:57 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:30:59 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:30:59 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:32:08 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:32:08 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:43:15 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 22:43:15 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:43:19 --- CRITICAL: ErrorException [ 1 ]: Class 'Controller_Common' not found ~ APPPATH\classes\Controller\Page.php [ 3 ] in file:line
2017-10-26 22:43:19 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 22:43:37 --- CRITICAL: View_Exception [ 0 ]: The requested view /pages/show could not be found ~ SYSPATH\classes\Kohana\View.php [ 265 ] in E:\OpenServer\domains\kohana\system\classes\Kohana\View.php:145
2017-10-26 22:43:37 --- DEBUG: #0 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(145): Kohana_View->set_filename('/pages/show')
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(30): Kohana_View->__construct('/pages/show', NULL)
#2 E:\OpenServer\domains\kohana\application\classes\Controller\Page.php(10): Kohana_View::factory('/pages/show')
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Page->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Page))
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#9 {main} in E:\OpenServer\domains\kohana\system\classes\Kohana\View.php:145
2017-10-26 23:07:48 --- CRITICAL: View_Exception [ 0 ]: The requested view /page/show could not be found ~ SYSPATH\classes\Kohana\View.php [ 265 ] in E:\OpenServer\domains\kohana\system\classes\Kohana\View.php:145
2017-10-26 23:07:48 --- DEBUG: #0 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(145): Kohana_View->set_filename('/page/show')
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\View.php(30): Kohana_View->__construct('/page/show', NULL)
#2 E:\OpenServer\domains\kohana\application\classes\Controller\Page.php(10): Kohana_View::factory('/page/show')
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Page->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Page))
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#9 {main} in E:\OpenServer\domains\kohana\system\classes\Kohana\View.php:145
2017-10-26 23:10:09 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 23:10:09 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 23:19:37 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 23:19:37 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 23:19:40 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 23:19:40 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 23:35:17 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 23:35:17 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 23:36:15 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 23:36:15 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 23:51:47 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 23:51:47 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 23:51:48 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of Error given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(Error))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-26 23:51:48 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-26 23:56:45 --- CRITICAL: ErrorException [ 2 ]: Creating default object from empty value ~ APPPATH\classes\Controller\Page.php [ 14 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Page.php:14
2017-10-26 23:56:45 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Page.php(14): Kohana_Core::error_handler(2, 'Creating defaul...', 'E:\\OpenServer\\d...', 14, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Page->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Page))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Page.php:14