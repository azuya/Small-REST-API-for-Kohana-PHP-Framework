<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2017-10-27 00:26:14 --- CRITICAL: ErrorException [ 2 ]: Creating default object from empty value ~ APPPATH\classes\Controller\Page.php [ 14 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Page.php:14
2017-10-27 00:26:14 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Page.php(14): Kohana_Core::error_handler(2, 'Creating defaul...', 'E:\\OpenServer\\d...', 14, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Page->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Page))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Page.php:14
2017-10-27 00:33:53 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of ParseError given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(ParseError))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-27 00:33:53 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 00:37:12 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of ParseError given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(ParseError))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-27 00:37:12 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 00:38:02 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of ParseError given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(ParseError))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-27 00:38:02 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 00:38:23 --- CRITICAL: ErrorException [ 1 ]: Uncaught TypeError: Argument 1 passed to Kohana_Kohana_Exception::handler() must be an instance of Exception, instance of ParseError given in E:\OpenServer\domains\kohana\system\classes\Kohana\Kohana\Exception.php:84
Stack trace:
#0 [internal function]: Kohana_Kohana_Exception::handler(Object(ParseError))
#1 {main}
  thrown ~ SYSPATH\classes\Kohana\Kohana\Exception.php [ 84 ] in file:line
2017-10-27 00:38:23 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 05:20:31 --- CRITICAL: ErrorException [ 1 ]: Class 'Model_Klass' not found ~ MODPATH\orm\classes\Kohana\ORM.php [ 46 ] in file:line
2017-10-27 05:20:31 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 05:21:17 --- CRITICAL: ErrorException [ 1 ]: Class 'Model_Api' not found ~ MODPATH\orm\classes\Kohana\ORM.php [ 46 ] in file:line
2017-10-27 05:21:17 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 05:23:12 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:23:12 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(23): Kohana_ORM::factory('Klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:24:17 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:24:17 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(28): Kohana_ORM::factory('Klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:24:22 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:24:22 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(28): Kohana_ORM::factory('Klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:25:14 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:25:14 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(28): Kohana_ORM::factory('Klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:51:28 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:51:28 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(28): Kohana_ORM::factory('Klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:51:30 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:51:30 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(28): Kohana_ORM::factory('Klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:52:26 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:52:26 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(28): Kohana_ORM::factory('Klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:52:27 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:52:27 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(28): Kohana_ORM::factory('Klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:53:55 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:53:55 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(29): Kohana_ORM::factory('Klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:54:08 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:54:08 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(29): Kohana_ORM::factory('klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:54:54 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:54:54 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(29): Kohana_ORM::factory('klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:54:56 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:54:56 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(29): Kohana_ORM::factory('klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:55:21 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:55:21 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(29): Kohana_ORM::factory('klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:55:44 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:55:44 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(29): Kohana_ORM::factory('klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:56:06 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 05:56:06 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(29): Kohana_ORM::factory('klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 06:01:45 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 06:01:45 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(29): Kohana_ORM::factory('Klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 06:01:56 --- CRITICAL: Kohana_Exception [ 0 ]: Database method list_columns is not supported by Kohana_Database_PDO ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 241 ] in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 06:01:56 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_PDO->list_columns('kla')
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#5 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(29): Kohana_ORM::factory('Klass')
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#9 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#12 {main} in E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php:1668
2017-10-27 06:20:05 --- CRITICAL: Database_Exception [ 8192 ]: mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead ~ MODPATH\database\classes\Kohana\Database\MySQL.php [ 67 ] in E:\OpenServer\domains\kohana\modules\database\classes\Kohana\Database\MySQL.php:171
2017-10-27 06:20:05 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\database\classes\Kohana\Database\MySQL.php(171): Kohana_Database_MySQL->connect()
#1 E:\OpenServer\domains\kohana\modules\database\classes\Kohana\Database\MySQL.php(359): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1668): Kohana_Database_MySQL->list_columns('kla')
#3 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(444): Kohana_ORM->list_columns()
#4 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(389): Kohana_ORM->reload_columns()
#5 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(254): Kohana_ORM->_initialize()
#6 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(46): Kohana_ORM->__construct(NULL)
#7 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(29): Kohana_ORM::factory('Klass')
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#9 [internal function]: Kohana_Controller->execute()
#10 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#11 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#13 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#14 {main} in E:\OpenServer\domains\kohana\modules\database\classes\Kohana\Database\MySQL.php:171
2017-10-27 06:22:37 --- CRITICAL: ErrorException [ 4096 ]: Object of class Database_MySQLi_Result could not be converted to string ~ APPPATH\classes\Controller\Api.php [ 30 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:30
2017-10-27 06:22:37 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(30): Kohana_Core::error_handler(4096, 'Object of class...', 'E:\\OpenServer\\d...', 30, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:30
2017-10-27 06:29:47 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Api.php [ 30 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:30
2017-10-27 06:29:47 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(30): Kohana_Core::error_handler(8, 'Undefined index...', 'E:\\OpenServer\\d...', 30, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:30
2017-10-27 06:30:18 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id ~ APPPATH\classes\Controller\Api.php [ 30 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:30
2017-10-27 06:30:18 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(30): Kohana_Core::error_handler(8, 'Undefined index...', 'E:\\OpenServer\\d...', 30, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:30
2017-10-27 06:30:54 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\Controller\Api.php [ 30 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:30
2017-10-27 06:30:54 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(30): Kohana_Core::error_handler(8, 'Array to string...', 'E:\\OpenServer\\d...', 30, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:30
2017-10-27 06:35:36 --- CRITICAL: ErrorException [ 1 ]: Call to a member function loaded() on array ~ APPPATH\classes\Controller\Api.php [ 31 ] in file:line
2017-10-27 06:35:36 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 06:41:47 --- CRITICAL: ErrorException [ 1 ]: Cannot use object of type Model_Klass as array ~ APPPATH\classes\Controller\Api.php [ 33 ] in file:line
2017-10-27 06:41:47 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 06:45:08 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ' ~ APPPATH\classes\Controller\Api.php [ 30 ] in file:line
2017-10-27 06:45:08 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 06:45:25 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ' ~ APPPATH\classes\Controller\Api.php [ 30 ] in file:line
2017-10-27 06:45:25 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 06:45:28 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ' ~ APPPATH\classes\Controller\Api.php [ 30 ] in file:line
2017-10-27 06:45:28 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 06:46:11 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ' ~ APPPATH\classes\Controller\Api.php [ 30 ] in file:line
2017-10-27 06:46:11 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 06:46:20 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ' ~ APPPATH\classes\Controller\Api.php [ 30 ] in file:line
2017-10-27 06:46:20 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 06:47:08 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'UTF' (T_STRING), expecting ',' or ';' ~ APPPATH\classes\Controller\Api.php [ 30 ] in file:line
2017-10-27 06:47:08 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 06:47:23 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'UTF' (T_STRING), expecting ',' or ';' ~ APPPATH\classes\Controller\Api.php [ 30 ] in file:line
2017-10-27 06:47:23 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 07:00:43 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH\classes\Controller\Api.php [ 47 ] in file:line
2017-10-27 07:00:43 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 07:00:54 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '}', expecting ',' or ';' ~ APPPATH\classes\Controller\Api.php [ 46 ] in file:line
2017-10-27 07:00:54 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 07:11:20 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH\classes\Controller\Api.php [ 47 ] in file:line
2017-10-27 07:11:20 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 07:17:52 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH\classes\Controller\Api.php [ 45 ] in file:line
2017-10-27 07:17:52 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 07:18:21 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH\classes\Controller\Api.php [ 45 ] in file:line
2017-10-27 07:18:21 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 07:19:11 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH\classes\Controller\Api.php [ 45 ] in file:line
2017-10-27 07:19:11 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 07:19:48 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'echo' (T_ECHO) ~ APPPATH\classes\Controller\Api.php [ 47 ] in file:line
2017-10-27 07:19:48 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 07:21:19 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'print_r' (T_STRING) ~ APPPATH\classes\Controller\Api.php [ 47 ] in file:line
2017-10-27 07:21:19 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 07:22:10 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$a' (T_VARIABLE), expecting ',' or ';' ~ APPPATH\classes\Controller\Api.php [ 47 ] in file:line
2017-10-27 07:22:10 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 07:25:18 --- CRITICAL: ErrorException [ 1 ]: Call to a member function as_array() on array ~ APPPATH\classes\Controller\Api.php [ 47 ] in file:line
2017-10-27 07:25:18 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 07:31:46 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: user ~ APPPATH\classes\Controller\Api.php [ 55 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:55
2017-10-27 07:31:46 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(55): Kohana_Core::error_handler(8, 'Undefined varia...', 'E:\\OpenServer\\d...', 55, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:55
2017-10-27 07:33:34 --- CRITICAL: ErrorException [ 8 ]: Undefined property: Database_MySQLi_Result::$id ~ APPPATH\classes\Controller\Api.php [ 55 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:55
2017-10-27 07:33:34 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(55): Kohana_Core::error_handler(8, 'Undefined prope...', 'E:\\OpenServer\\d...', 55, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:55
2017-10-27 07:33:56 --- CRITICAL: ErrorException [ 8 ]: Undefined property: Database_MySQLi_Result::$id ~ APPPATH\classes\Controller\Api.php [ 55 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:55
2017-10-27 07:33:56 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(55): Kohana_Core::error_handler(8, 'Undefined prope...', 'E:\\OpenServer\\d...', 55, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:55
2017-10-27 07:36:41 --- CRITICAL: ErrorException [ 8 ]: Undefined property: Database_MySQLi_Result::$id ~ APPPATH\classes\Controller\Api.php [ 55 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:55
2017-10-27 07:36:41 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(55): Kohana_Core::error_handler(8, 'Undefined prope...', 'E:\\OpenServer\\d...', 55, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:55
2017-10-27 07:56:40 --- CRITICAL: ErrorException [ 1 ]: Call to a member function as_array() on string ~ APPPATH\classes\Controller\Api.php [ 52 ] in file:line
2017-10-27 07:56:40 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 15:18:36 --- CRITICAL: ErrorException [ 8 ]: Object of class Model_Klass could not be converted to int ~ APPPATH\classes\Controller\Api.php [ 65 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:65
2017-10-27 15:18:36 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(65): Kohana_Core::error_handler(8, 'Object of class...', 'E:\\OpenServer\\d...', 65, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_active()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:65
2017-10-27 15:19:48 --- CRITICAL: ErrorException [ 8 ]: Object of class Model_Klass could not be converted to int ~ APPPATH\classes\Controller\Api.php [ 65 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:65
2017-10-27 15:19:48 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(65): Kohana_Core::error_handler(8, 'Object of class...', 'E:\\OpenServer\\d...', 65, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_active()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:65
2017-10-27 15:19:50 --- CRITICAL: ErrorException [ 8 ]: Object of class Model_Klass could not be converted to int ~ APPPATH\classes\Controller\Api.php [ 65 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:65
2017-10-27 15:19:50 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(65): Kohana_Core::error_handler(8, 'Object of class...', 'E:\\OpenServer\\d...', 65, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_active()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:65
2017-10-27 15:20:14 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'ORM' (T_STRING) ~ APPPATH\classes\Controller\Api.php [ 64 ] in file:line
2017-10-27 15:20:14 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 15:20:23 --- CRITICAL: ErrorException [ 8 ]: Object of class Model_Klass could not be converted to int ~ APPPATH\classes\Controller\Api.php [ 64 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:64
2017-10-27 15:20:23 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(64): Kohana_Core::error_handler(8, 'Object of class...', 'E:\\OpenServer\\d...', 64, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_active()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:64
2017-10-27 15:35:04 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' ~ APPPATH\classes\Controller\Api.php [ 64 ] in file:line
2017-10-27 15:35:04 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-10-27 15:36:05 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\Controller\Api.php [ 66 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:66
2017-10-27 15:36:05 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(66): Kohana_Core::error_handler(8, 'Array to string...', 'E:\\OpenServer\\d...', 66, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_active()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:66
2017-10-27 15:36:19 --- CRITICAL: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH\classes\Controller\Api.php [ 66 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:66
2017-10-27 15:36:19 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(66): Kohana_Core::error_handler(8, 'Undefined offse...', 'E:\\OpenServer\\d...', 66, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_active()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:66
2017-10-27 15:39:42 --- CRITICAL: Database_Exception [ 1364 ]: Field 'name' doesn't have a default value [ INSERT INTO `kla` (`active`) VALUES (0) ] ~ MODPATH\database\classes\Kohana\Database\MySQLi.php [ 171 ] in E:\OpenServer\domains\kohana\modules\database\classes\Kohana\Database\Query.php:251
2017-10-27 15:39:42 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQLi->query(2, 'INSERT INTO `kl...', false, Array)
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1324): Kohana_Database_Query->execute(Object(Database_MySQLi))
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1421): Kohana_ORM->create(NULL)
#3 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(71): Kohana_ORM->save()
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_active()
#5 [internal function]: Kohana_Controller->execute()
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#7 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#10 {main} in E:\OpenServer\domains\kohana\modules\database\classes\Kohana\Database\Query.php:251
2017-10-27 15:40:43 --- CRITICAL: Database_Exception [ 1364 ]: Field 'name' doesn't have a default value [ INSERT INTO `kla` (`active`) VALUES ('0') ] ~ MODPATH\database\classes\Kohana\Database\MySQLi.php [ 171 ] in E:\OpenServer\domains\kohana\modules\database\classes\Kohana\Database\Query.php:251
2017-10-27 15:40:43 --- DEBUG: #0 E:\OpenServer\domains\kohana\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQLi->query(2, 'INSERT INTO `kl...', false, Array)
#1 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1324): Kohana_Database_Query->execute(Object(Database_MySQLi))
#2 E:\OpenServer\domains\kohana\modules\orm\classes\Kohana\ORM.php(1421): Kohana_ORM->create(NULL)
#3 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(71): Kohana_ORM->save()
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_active()
#5 [internal function]: Kohana_Controller->execute()
#6 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#7 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#10 {main} in E:\OpenServer\domains\kohana\modules\database\classes\Kohana\Database\Query.php:251
2017-10-27 15:43:00 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\Controller\Api.php [ 74 ] in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:74
2017-10-27 15:43:00 --- DEBUG: #0 E:\OpenServer\domains\kohana\application\classes\Controller\Api.php(74): Kohana_Core::error_handler(8, 'Array to string...', 'E:\\OpenServer\\d...', 74, Array)
#1 E:\OpenServer\domains\kohana\system\classes\Kohana\Controller.php(84): Controller_Api->action_active()
#2 [internal function]: Kohana_Controller->execute()
#3 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Api))
#4 E:\OpenServer\domains\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 E:\OpenServer\domains\kohana\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 E:\OpenServer\domains\kohana\index.php(118): Kohana_Request->execute()
#7 {main} in E:\OpenServer\domains\kohana\application\classes\Controller\Api.php:74