<h1><?=$title?></h1>
<hr>
<?=$content?>

