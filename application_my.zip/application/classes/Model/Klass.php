<?php defined('SYSPATH') or die('No direct script access.');

class Model_Klass extends ORM {
    
    protected $_table_name = 'kla';
 
}

/*class Model_Klass extends Model {
    
   protected $tableName = 'articles';
    
    public function get_all()
    {
    $sql = "SELECT * FROM ". $this->tableName;
 
        return DB::query(Database::SELECT, $sql)->execute();
        
    }
    
  	
    
}
*/
