<?php defined('SYSPATH') or die('No direct script access.');

class Model_Catalog extends Model {

	public function all_products()
	{
                return array (
                    "Item 1" => 100,
                    "Item 2" => 200,
                    "Item 3" => 300,
                    "Item 4" => 300,
                );
                       
	}
        


}
